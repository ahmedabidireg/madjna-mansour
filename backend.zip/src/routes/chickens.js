const express = require('express');
const { Chicken, HealthEvent } = require('../models');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Get all chickens
router.get('/', authenticateToken, async (req, res) => {
  try {
    const chickens = await Chicken.find().sort({ created_at: -1 });
    res.json(chickens);
  } catch (error) {
    console.error('Get chickens error:', error);
    res.status(500).json({ error: 'Failed to fetch chickens' });
  }
});

// Get chicken by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const chicken = await Chicken.findById(req.params.id);
    if (!chicken) {
      return res.status(404).json({ error: 'Chicken not found' });
    }
    res.json(chicken);
  } catch (error) {
    console.error('Get chicken error:', error);
    res.status(500).json({ error: 'Failed to fetch chicken' });
  }
});

// Create new chicken
router.post('/', authenticateToken, async (req, res) => {
  try {
    const chicken = new Chicken(req.body);
    await chicken.save();
    res.status(201).json(chicken);
  } catch (error) {
    console.error('Create chicken error:', error);
    res.status(500).json({ error: 'Failed to create chicken' });
  }
});

// Update chicken
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const chicken = await Chicken.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!chicken) {
      return res.status(404).json({ error: 'Chicken not found' });
    }
    res.json(chicken);
  } catch (error) {
    console.error('Update chicken error:', error);
    res.status(500).json({ error: 'Failed to update chicken' });
  }
});

// Delete chicken
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const chicken = await Chicken.findByIdAndDelete(req.params.id);
    if (!chicken) {
      return res.status(404).json({ error: 'Chicken not found' });
    }
    res.json({ message: 'Chicken deleted successfully' });
  } catch (error) {
    console.error('Delete chicken error:', error);
    res.status(500).json({ error: 'Failed to delete chicken' });
  }
});

// Get health events for a chicken
router.get('/:id/health-events', authenticateToken, async (req, res) => {
  try {
    const healthEvents = await HealthEvent.find({ chicken_id: req.params.id })
      .sort({ date: -1 });
    res.json(healthEvents);
  } catch (error) {
    console.error('Get health events error:', error);
    res.status(500).json({ error: 'Failed to fetch health events' });
  }
});

// Add health event
router.post('/:id/health-events', authenticateToken, async (req, res) => {
  try {
    const healthEvent = new HealthEvent({
      ...req.body,
      chicken_id: req.params.id
    });
    await healthEvent.save();
    res.status(201).json(healthEvent);
  } catch (error) {
    console.error('Create health event error:', error);
    res.status(500).json({ error: 'Failed to create health event' });
  }
});

module.exports = router;
