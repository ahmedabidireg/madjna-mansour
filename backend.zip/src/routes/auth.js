const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { User } = require('../models');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Register
router.post('/register', async (req, res) => {
  try {
    const { email, password, name, role = 'employee' } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);

    // Create user
    const user = new User({
      email,
      password: hashedPassword,
      name,
      role,
      permissions: getDefaultPermissions(role)
    });

    await user.save();

    // Generate token
    const token = jwt.sign(
      { userId: user._id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      message: 'User created successfully',
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Check password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Update last login
    user.last_login = new Date();
    await user.save();

    // Generate token
    const token = jwt.sign(
      { userId: user._id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
        role: user.role,
        permissions: user.permissions
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// Get current user
router.get('/me', authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId).select('-password');
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: 'Failed to get user' });
  }
});

// Logout (client-side token removal)
router.post('/logout', authenticateToken, (req, res) => {
  res.json({ message: 'Logout successful' });
});

// Helper function to get default permissions based on role
function getDefaultPermissions(role) {
  const permissions = {
    admin: [
      { module: 'chickens', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'eggs', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'sales', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'expenses', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'cartons', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'reports', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'users', actions: ['read', 'create', 'update', 'delete'] }
    ],
    manager: [
      { module: 'chickens', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'eggs', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'sales', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'expenses', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'cartons', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'reports', actions: ['read'] },
      { module: 'users', actions: ['read'] }
    ],
    employee: [
      { module: 'chickens', actions: ['read', 'create', 'update'] },
      { module: 'eggs', actions: ['read', 'create', 'update'] },
      { module: 'sales', actions: ['read', 'create'] },
      { module: 'expenses', actions: ['read', 'create'] },
      { module: 'cartons', actions: ['read', 'create', 'update'] },
      { module: 'reports', actions: ['read'] },
      { module: 'users', actions: ['read'] }
    ],
    viewer: [
      { module: 'chickens', actions: ['read'] },
      { module: 'eggs', actions: ['read'] },
      { module: 'sales', actions: ['read'] },
      { module: 'expenses', actions: ['read'] },
      { module: 'cartons', actions: ['read'] },
      { module: 'reports', actions: ['read'] },
      { module: 'users', actions: ['read'] }
    ]
  };

  return permissions[role] || permissions.viewer;
}

module.exports = router;
