const express = require('express');
const { Chicken, EggProduction, Sale, Expense, Carton } = require('../models');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Get dashboard statistics
router.get('/stats', authenticateToken, async (req, res) => {
  try {
    const now = new Date();
    const startOfDay = new Date(now);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(now);
    endOfDay.setHours(23, 59, 59, 999);
    
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay());
    startOfWeek.setHours(0, 0, 0, 0);
    
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    // Chicken statistics - sum the count field from all batches
    const chickenStats = await Chicken.aggregate([
      {
        $group: {
          _id: null,
          totalChickens: { $sum: '$count' },
          aliveChickens: {
            $sum: {
              $cond: [{ $eq: ['$status', 'alive'] }, '$count', 0]
            }
          },
          sickChickens: {
            $sum: {
              $cond: [{ $eq: ['$status', 'sick'] }, '$count', 0]
            }
          },
          deadChickens: {
            $sum: {
              $cond: [{ $eq: ['$status', 'dead'] }, '$count', 0]
            }
          }
        }
      }
    ]);

    const totalChickens = chickenStats[0]?.totalChickens || 0;
    const aliveChickens = chickenStats[0]?.aliveChickens || 0;
    const sickChickens = chickenStats[0]?.sickChickens || 0;
    const deadChickens = chickenStats[0]?.deadChickens || 0;

    // Egg production statistics
    const todayEggs = await EggProduction.aggregate([
      { $match: { date: { $gte: startOfDay, $lte: endOfDay } } },
      { $group: { _id: null, total: { $sum: '$total_eggs' } } }
    ]);

    const weeklyEggs = await EggProduction.aggregate([
      { $match: { date: { $gte: startOfWeek } } },
      { $group: { _id: null, total: { $sum: '$total_eggs' } } }
    ]);

    const monthlyEggs = await EggProduction.aggregate([
      { $match: { date: { $gte: startOfMonth } } },
      { $group: { _id: null, total: { $sum: '$total_eggs' } } }
    ]);

    // Revenue and expenses
    const totalRevenue = await Sale.aggregate([
      { $group: { _id: null, total: { $sum: '$total_amount' } } }
    ]);

    const totalExpenses = await Expense.aggregate([
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);

    // Low stock cartons
    const lowStockCartons = await Carton.find({ available_quantity: { $lt: 10 } });

    // Calculate damage rate
    const damageStats = await EggProduction.aggregate([
      {
        $group: {
          _id: null,
          totalEggs: { $sum: '$total_eggs' },
          damagedEggs: { $sum: '$damaged_eggs' }
        }
      }
    ]);

    const damageRate = damageStats.length > 0 
      ? (damageStats[0].damagedEggs / damageStats[0].totalEggs) * 100 
      : 0;

    const profit = (totalRevenue[0]?.total || 0) - (totalExpenses[0]?.total || 0);

    res.json({
      totalChickens,
      aliveChickens,
      sickChickens,
      deadChickens,
      todayEggs: todayEggs[0]?.total || 0,
      weeklyEggs: weeklyEggs[0]?.total || 0,
      monthlyEggs: monthlyEggs[0]?.total || 0,
      damageRate: Math.round(damageRate * 100) / 100,
      totalRevenue: totalRevenue[0]?.total || 0,
      totalExpenses: totalExpenses[0]?.total || 0,
      profit,
      lowStockCartons
    });
  } catch (error) {
    console.error('Get dashboard stats error:', error);
    res.status(500).json({ error: 'Failed to fetch dashboard statistics' });
  }
});

module.exports = router;
