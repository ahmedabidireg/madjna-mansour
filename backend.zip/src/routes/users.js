const express = require('express');
const bcrypt = require('bcryptjs');
const { User } = require('../models');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// Get all users
router.get('/', authenticateToken, requireRole(['admin', 'manager']), async (req, res) => {
  try {
    const users = await User.find().select('-password').sort({ created_at: -1 });
    res.json(users);
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// Create new user
router.post('/', authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const { email, password, name, role = 'employee' } = req.body;

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    const user = new User({
      email,
      password: hashedPassword,
      name,
      role,
      permissions: getDefaultPermissions(role)
    });

    await user.save();

    res.status(201).json({
      message: 'User created successfully',
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Create user error:', error);
    res.status(500).json({ error: 'Failed to create user' });
  }
});

// Update user
router.put('/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    ).select('-password');
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    console.error('Update user error:', error);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

// Delete user
router.delete('/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

function getDefaultPermissions(role) {
  const permissions = {
    admin: [
      { module: 'chickens', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'eggs', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'sales', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'expenses', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'cartons', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'reports', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'users', actions: ['read', 'create', 'update', 'delete'] }
    ],
    manager: [
      { module: 'chickens', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'eggs', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'sales', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'expenses', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'cartons', actions: ['read', 'create', 'update', 'delete'] },
      { module: 'reports', actions: ['read'] },
      { module: 'users', actions: ['read'] }
    ],
    employee: [
      { module: 'chickens', actions: ['read', 'create', 'update'] },
      { module: 'eggs', actions: ['read', 'create', 'update'] },
      { module: 'sales', actions: ['read', 'create'] },
      { module: 'expenses', actions: ['read', 'create'] },
      { module: 'cartons', actions: ['read', 'create', 'update'] },
      { module: 'reports', actions: ['read'] },
      { module: 'users', actions: ['read'] }
    ],
    viewer: [
      { module: 'chickens', actions: ['read'] },
      { module: 'eggs', actions: ['read'] },
      { module: 'sales', actions: ['read'] },
      { module: 'expenses', actions: ['read'] },
      { module: 'cartons', actions: ['read'] },
      { module: 'reports', actions: ['read'] },
      { module: 'users', actions: ['read'] }
    ]
  };

  return permissions[role] || permissions.viewer;
}

module.exports = router;
