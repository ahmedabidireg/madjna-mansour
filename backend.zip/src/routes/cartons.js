const express = require('express');
const { Carton } = require('../models');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Get all cartons
router.get('/', authenticateToken, async (req, res) => {
  try {
    const cartons = await Carton.find().sort({ type: 1 });
    res.json(cartons);
  } catch (error) {
    console.error('Get cartons error:', error);
    res.status(500).json({ error: 'Failed to fetch cartons' });
  }
});

// Create new carton
router.post('/', authenticateToken, async (req, res) => {
  try {
    const carton = new Carton(req.body);
    await carton.save();
    res.status(201).json(carton);
  } catch (error) {
    console.error('Create carton error:', error);
    res.status(500).json({ error: 'Failed to create carton' });
  }
});

// Update carton
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const carton = await Carton.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!carton) {
      return res.status(404).json({ error: 'Carton not found' });
    }
    res.json(carton);
  } catch (error) {
    console.error('Update carton error:', error);
    res.status(500).json({ error: 'Failed to update carton' });
  }
});

// Delete carton
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const carton = await Carton.findByIdAndDelete(req.params.id);
    if (!carton) {
      return res.status(404).json({ error: 'Carton not found' });
    }
    res.json({ message: 'Carton deleted successfully' });
  } catch (error) {
    console.error('Delete carton error:', error);
    res.status(500).json({ error: 'Failed to delete carton' });
  }
});

module.exports = router;
