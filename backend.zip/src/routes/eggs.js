const express = require('express');
const { EggProduction } = require('../models');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Get all egg productions
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    let query = {};
    
    if (startDate && endDate) {
      query = {
        date: {
          $gte: new Date(startDate),
          $lte: new Date(endDate)
        }
      };
    }
    
    const eggProductions = await EggProduction.find(query).sort({ date: -1 });
    res.json(eggProductions);
  } catch (error) {
    console.error('Get egg productions error:', error);
    res.status(500).json({ error: 'Failed to fetch egg productions' });
  }
});

// Get egg production by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const eggProduction = await EggProduction.findById(req.params.id);
    if (!eggProduction) {
      return res.status(404).json({ error: 'Egg production not found' });
    }
    res.json(eggProduction);
  } catch (error) {
    console.error('Get egg production error:', error);
    res.status(500).json({ error: 'Failed to fetch egg production' });
  }
});

// Create new egg production
router.post('/', authenticateToken, async (req, res) => {
  try {
    const eggProduction = new EggProduction(req.body);
    await eggProduction.save();
    res.status(201).json(eggProduction);
  } catch (error) {
    console.error('Create egg production error:', error);
    res.status(500).json({ error: 'Failed to create egg production' });
  }
});

// Update egg production
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const eggProduction = await EggProduction.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!eggProduction) {
      return res.status(404).json({ error: 'Egg production not found' });
    }
    res.json(eggProduction);
  } catch (error) {
    console.error('Update egg production error:', error);
    res.status(500).json({ error: 'Failed to update egg production' });
  }
});

// Delete egg production
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const eggProduction = await EggProduction.findByIdAndDelete(req.params.id);
    if (!eggProduction) {
      return res.status(404).json({ error: 'Egg production not found' });
    }
    res.json({ message: 'Egg production deleted successfully' });
  } catch (error) {
    console.error('Delete egg production error:', error);
    res.status(500).json({ error: 'Failed to delete egg production' });
  }
});

module.exports = router;
