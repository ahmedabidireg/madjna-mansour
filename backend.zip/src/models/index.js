const mongoose = require('mongoose');
const { Schema } = mongoose;

// User Permission Schema
const UserPermissionSchema = new Schema({
  module: {
    type: String,
    enum: ['chickens', 'eggs', 'sales', 'expenses', 'cartons', 'reports', 'users'],
    required: true
  },
  actions: [{
    type: String,
    enum: ['read', 'create', 'update', 'delete']
  }]
});

// User Schema
const UserSchema = new Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  name: { type: String, required: true },
  role: { 
    type: String, 
    enum: ['admin', 'manager', 'employee', 'viewer'], 
    default: 'employee' 
  },
  phone: String,
  avatar: String,
  status: { 
    type: String, 
    enum: ['active', 'inactive', 'suspended'], 
    default: 'active' 
  },
  permissions: [UserPermissionSchema],
  created_at: { type: Date, default: Date.now },
  updated_at: Date,
  last_login: Date
});

const User = mongoose.model('User', UserSchema);

// Chicken Schema
const ChickenSchema = new Schema({
  batch_number: { type: String, required: true },
  breed: { type: String, required: true },
  count: { type: Number, required: true },
  age_weeks: { type: Number, required: true },
  purchase_date: { type: Date, required: true },
  purchase_price: { type: Number, required: true },
  status: { 
    type: String, 
    enum: ['alive', 'sick', 'dead'], 
    default: 'alive' 
  },
  notes: String,
  created_at: { type: Date, default: Date.now }
});

const Chicken = mongoose.model('Chicken', ChickenSchema);

// Health Event Schema
const HealthEventSchema = new Schema({
  chicken_id: { type: String, required: true },
  event_type: { 
    type: String, 
    enum: ['vaccination', 'treatment', 'checkup', 'death', 'illness'],
    required: true 
  },
  date: { type: Date, required: true },
  description: { type: String, required: true },
  medication: String,
  dosage: String,
  veterinarian: String,
  cost: Number,
  notes: String
});

const HealthEvent = mongoose.model('HealthEvent', HealthEventSchema);

// Egg Production Schema
const EggProductionSchema = new Schema({
  date: { type: Date, required: true },
  total_eggs: { type: Number, required: true },
  damaged_eggs: { type: Number, required: true },
  good_eggs: { type: Number, required: true },
  collection_time: { type: String, required: true },
  notes: String
});

const EggProduction = mongoose.model('EggProduction', EggProductionSchema);

// Client Schema
const ClientSchema = new Schema({
  name: { type: String, required: true },
  phone: { type: String, required: true },
  email: String,
  address: String,
  notes: String,
  created_at: { type: Date, default: Date.now }
});

const Client = mongoose.model('Client', ClientSchema);

// Sale Item Schema
const SaleItemSchema = new Schema({
  product_type: { 
    type: String, 
    enum: ['eggs', 'chicken', 'carton'],
    required: true 
  },
  quantity: { type: Number, required: true },
  unit_price: { type: Number, required: true },
  total_price: { type: Number, required: true },
  description: String
});

// Sale Schema
const SaleSchema = new Schema({
  client_id: String,
  client_name: { type: String, required: true },
  client_phone: String,
  sale_date: { type: Date, required: true },
  items: [SaleItemSchema],
  total_amount: { type: Number, required: true },
  payment_status: { 
    type: String, 
    enum: ['paid', 'pending', 'partial'],
    default: 'pending' 
  },
  payment_method: { 
    type: String, 
    enum: ['cash', 'transfer', 'check'] 
  },
  invoice_number: { type: String, required: true },
  notes: String
});

const Sale = mongoose.model('Sale', SaleSchema);

// Expense Schema
const ExpenseSchema = new Schema({
  date: { type: Date, required: true },
  category: { 
    type: String, 
    enum: ['feed', 'medicine', 'water', 'electricity', 'supplies', 'maintenance', 'other'],
    required: true 
  },
  description: { type: String, required: true },
  amount: { type: Number, required: true },
  notes: String
});

const Expense = mongoose.model('Expense', ExpenseSchema);

// Carton Schema
const CartonSchema = new Schema({
  type: { type: String, required: true },
  capacity: { type: Number, required: true },
  available_quantity: { type: Number, required: true },
  purchase_price: { type: Number, required: true },
  supplier: String,
  purchase_date: Date
});

const Carton = mongoose.model('Carton', CartonSchema);

// Vaccination Schema
const VaccinationSchema = new Schema({
  chicken_batch_id: { type: String, required: true },
  vaccine_name: { type: String, required: true },
  date: { type: Date, required: true },
  dosage: { type: String, required: true },
  veterinarian: String,
  cost: Number,
  next_vaccination_date: Date,
  notes: String
});

const Vaccination = mongoose.model('Vaccination', VaccinationSchema);

// User Activity Schema
const UserActivitySchema = new Schema({
  user_id: { type: String, required: true },
  action: { type: String, required: true },
  module: { type: String, required: true },
  description: { type: String, required: true },
  timestamp: { type: Date, default: Date.now },
  ip_address: String
});

const UserActivity = mongoose.model('UserActivity', UserActivitySchema);

module.exports = {
  User,
  Chicken,
  HealthEvent,
  EggProduction,
  Client,
  Sale,
  Expense,
  Carton,
  Vaccination,
  UserActivity
};
