# Lazher - Express + MongoDB Backend

This is the backend API for the Lazher poultry management application, built with Express.js and MongoDB.

## Features

- **Authentication**: JWT-based authentication with role-based access control
- **Chicken Management**: Track chicken batches, health events, and vaccinations
- **Egg Production**: Record daily egg production with damage tracking
- **Sales Management**: Handle sales transactions and client management
- **Expense Tracking**: Categorize and track farm expenses
- **Carton Management**: Manage egg carton inventory
- **User Management**: Multi-user support with different permission levels
- **Dashboard Statistics**: Real-time analytics and reporting

## Setup Instructions

### Prerequisites

- Node.js (v16 or higher)
- MongoDB (local installation or MongoDB Atlas)
- npm or yarn

### Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Environment Configuration:**
   Create a `.env` file in the backend directory:
   ```env
   MONGODB_URI=mongodb://localhost:27017/lazher
   JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
   PORT=3001
   FRONTEND_URL=http://localhost:5173
   ```

3. **Start MongoDB:**
   - Local: Start your MongoDB service
   - Atlas: Use your MongoDB Atlas connection string

4. **Run the application:**
   ```bash
   # Development mode
   npm run dev
   
   # Production build
   npm run build
   npm start
   ```

### API Endpoints

#### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user
- `POST /api/auth/logout` - User logout

#### Chickens
- `GET /api/chickens` - Get all chickens
- `POST /api/chickens` - Create new chicken
- `GET /api/chickens/:id` - Get chicken by ID
- `PUT /api/chickens/:id` - Update chicken
- `DELETE /api/chickens/:id` - Delete chicken
- `GET /api/chickens/:id/health-events` - Get health events
- `POST /api/chickens/:id/health-events` - Add health event

#### Eggs
- `GET /api/eggs` - Get egg productions
- `POST /api/eggs` - Create egg production record
- `PUT /api/eggs/:id` - Update egg production
- `DELETE /api/eggs/:id` - Delete egg production

#### Sales
- `GET /api/sales` - Get all sales
- `POST /api/sales` - Create new sale
- `PUT /api/sales/:id` - Update sale
- `DELETE /api/sales/:id` - Delete sale
- `GET /api/sales/clients/all` - Get all clients
- `POST /api/sales/clients` - Create new client

#### Expenses
- `GET /api/expenses` - Get all expenses
- `POST /api/expenses` - Create new expense
- `PUT /api/expenses/:id` - Update expense
- `DELETE /api/expenses/:id` - Delete expense

#### Cartons
- `GET /api/cartons` - Get all cartons
- `POST /api/cartons` - Create new carton
- `PUT /api/cartons/:id` - Update carton
- `DELETE /api/cartons/:id` - Delete carton

#### Users
- `GET /api/users` - Get all users (admin/manager only)
- `POST /api/users` - Create new user (admin only)
- `PUT /api/users/:id` - Update user (admin only)
- `DELETE /api/users/:id` - Delete user (admin only)

#### Dashboard
- `GET /api/dashboard/stats` - Get dashboard statistics

#### Health Check
- `GET /api/health` - API health status

### User Roles and Permissions

- **Admin**: Full access to all modules
- **Manager**: Full access to farm operations, read-only access to reports and users
- **Employee**: Create/update access to farm operations, read-only access to reports
- **Viewer**: Read-only access to all modules

### Database Schema

The application uses MongoDB with the following main collections:
- `users` - User accounts and permissions
- `chickens` - Chicken batch information
- `healthevents` - Health event records
- `eggproductions` - Daily egg production records
- `sales` - Sales transactions
- `clients` - Customer information
- `expenses` - Expense records
- `cartons` - Carton inventory
- `vaccinations` - Vaccination records
- `useractivities` - User activity logs

### Frontend Integration

The frontend has been updated to use this API instead of Supabase. The main changes include:

1. **API Service**: New `src/services/api.ts` handles all API communication
2. **Authentication**: Updated `AuthContext` to use JWT tokens
3. **Database Service**: Updated to use API calls with localStorage fallback
4. **Environment Variables**: Frontend uses `VITE_API_URL` to connect to backend

### Development

- **Hot Reload**: Uses nodemon for automatic server restart
- **TypeScript**: Full TypeScript support with type checking
- **Error Handling**: Comprehensive error handling and logging
- **CORS**: Configured for frontend development
- **Validation**: Request validation using Mongoose schemas

### Production Deployment

1. Set `NODE_ENV=production`
2. Use a strong JWT secret
3. Configure proper MongoDB connection string
4. Set up reverse proxy (nginx)
5. Use PM2 for process management
6. Enable HTTPS

### Troubleshooting

- **Connection Issues**: Check MongoDB connection string and service status
- **Authentication Errors**: Verify JWT secret and token expiration
- **CORS Issues**: Ensure frontend URL is correctly configured
- **Database Errors**: Check MongoDB logs and connection status
